package AppointmentService.java;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    //Creating method to schedule appointments
    public void scheduleAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("An appointment with this ID already exists.");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    //Creating method to cancel appointmnet by id
    public void cancelAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("No appointment found with this ID.");
        }
        appointments.remove(appointmentId);
    }

    //Creating method to retrieve information from appointment by id
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
