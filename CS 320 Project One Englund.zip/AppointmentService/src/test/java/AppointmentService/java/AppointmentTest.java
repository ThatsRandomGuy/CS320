package AppointmentService.java;

import junit.framework.TestCase;

public class AppointmentTest extends TestCase {

	public void testAppointment() {
		fail("Not yet implemented");
	}

	public void testGetAppointmentId() {
		fail("Not yet implemented");
	}

	public void testGetAppointmentDate() {
		fail("Not yet implemented");
	}

	public void testGetDescription() {
		fail("Not yet implemented");
	}

	public void testSetDescription() {
		fail("Not yet implemented");
	}

}
