package AppointmentService.java;

import junit.framework.TestCase;

public class AppointmentServiceTest extends TestCase {

	public void testScheduleAppointment() {
		fail("Not yet implemented");
	}

	public void testCancelAppointment() {
		fail("Not yet implemented");
	}

	public void testGetAppointment() {
		fail("Not yet implemented");
	}

}
