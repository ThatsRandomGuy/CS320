package TaskService.java;

import junit.framework.TestCase;

public class TaskTest extends TestCase {

	public void testTask() {
		fail("Not yet implemented");
	}

	public void testGetTaskId() {
		fail("Not yet implemented");
	}

	public void testGetName() {
		fail("Not yet implemented");
	}

	public void testGetDescription() {
		fail("Not yet implemented");
	}

	public void testSetName() {
		fail("Not yet implemented");
	}

	public void testSetDescription() {
		fail("Not yet implemented");
	}

}
