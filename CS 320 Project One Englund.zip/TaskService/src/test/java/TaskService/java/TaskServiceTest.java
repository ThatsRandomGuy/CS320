package TaskService.java;

import junit.framework.TestCase;

public class TaskServiceTest extends TestCase {

	public void testAddTask() {
		fail("Not yet implemented");
	}

	public void testRemoveTask() {
		fail("Not yet implemented");
	}

	public void testModifyTask() {
		fail("Not yet implemented");
	}

	public void testFetchTask() {
		fail("Not yet implemented");
	}

}
