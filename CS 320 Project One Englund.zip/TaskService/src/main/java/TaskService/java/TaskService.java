package TaskService.java;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> taskMap = new HashMap<>();

    //Creating method to add tasks
    public void addTask(Task task) {
        if (taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("A task with this ID already exists.");
        }
        taskMap.put(task.getTaskId(), task);
    }

    //Creating method to remove task by id
    public void removeTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("No task found with this ID.");
        }
        taskMap.remove(taskId);
    }

    //Creating method to modify task
    public void modifyTask(String taskId, String name, String description) {
        Task task = taskMap.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("No task found with this ID.");
        }
        if (name != null && !name.isEmpty()) {
            task.setName(name);
        }
        if (description != null && !description.isEmpty()) {
            task.setDescription(description);
        }
    }

    //Creating method to display task information
    public Task fetchTask(String taskId) {
        return taskMap.get(taskId);
    }
}