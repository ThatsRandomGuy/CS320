package ContactService.java;

import junit.framework.TestCase;

public class ContactTest extends TestCase {

	public void testContact() {
		fail("Not yet implemented");
	}

	public void testGetContactId() {
		fail("Not yet implemented");
	}

	public void testGetFirstName() {
		fail("Not yet implemented");
	}

	public void testGetLastName() {
		fail("Not yet implemented");
	}

	public void testGetPhone() {
		fail("Not yet implemented");
	}

	public void testGetAddress() {
		fail("Not yet implemented");
	}

	public void testSetFirstName() {
		fail("Not yet implemented");
	}

	public void testSetLastName() {
		fail("Not yet implemented");
	}

	public void testSetPhone() {
		fail("Not yet implemented");
	}

	public void testSetAddress() {
		fail("Not yet implemented");
	}

}
