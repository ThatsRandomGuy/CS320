package ContactService.java;

import junit.framework.TestCase;

public class ContactServiceTest extends TestCase {

	public void testAddContact() {
		fail("Not yet implemented");
	}

	public void testDeleteContact() {
		fail("Not yet implemented");
	}

	public void testUpdateContact() {
		fail("Not yet implemented");
	}

	public void testGetContact() {
		fail("Not yet implemented");
	}

}
